#include <stdio.h>
int main (int argc, char *argv[]) {
    printf ("Hola Mundo\n");
    return 0;
}

